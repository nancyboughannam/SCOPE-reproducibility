"""R1.10 paired, closed-loop prediction-noise experiment."""
import argparse
import csv
import fcntl
import hashlib
import importlib.metadata
import json
import os
import platform
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path
import zipfile

import run_confirmatory_study as study
import run_deadline_pilot as core
from local_inputs import stage_inputs

ROOT = Path(__file__).resolve().parents[1]
LEVELS = (0, 1, 2)
TARGETS = ("failure_rate", "deadline_norm_service_time")


def read_csv(path):
    with path.open(newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path, rows):
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def model_scales(out):
    return {(int(r["app_id"]), r["target"]): float(r["rmse"])
            for r in read_csv(out/"models/model_metrics.csv")
            if (r["model_type"], r["split"]) == ("candidate_aware_xgboost", "validation")}


def check_noise(folder, plan, job, scales):
    rows = read_csv(folder/"noise_audit.csv")
    expected = {(t, app, target) for t in range(70, plan["minutes"]*60, 60)
                for app in range(3) for target in TARGETS}
    draws = []
    sim_seeds = set()
    for r in rows:
        ident = int(r["timestamp"]), int(r["app"]), r["target"]
        if ident not in expected:
            raise ValueError(f"Unexpected or duplicate prediction batch in {folder}: {ident}")
        expected.remove(ident)
        level = job["noise_level"]
        scale = scales[ident[1:]]
        maximum, rms = float(r["max_abs_added"]), float(r["rms_added"])
        if not (int(r["iteration"]) == job["iteration"] and int(r["level"]) == level
                and int(r["candidates"]) in (1408, 1409) and float(r["rmse"]) == scale
                and float(r["sigma"]) == level * scale):
            raise ValueError(f"Noise settings inconsistent with study in {folder}")
        if level:
            if not (0 < rms <= maximum < float("inf") and len(r["catalogue_draw_sha256"]) == 64):
                raise ValueError(f"Missing noise for {ident}")
            draws.append((ident, r["catalogue_draw_sha256"]))
        elif maximum != 0 or rms != 0 or r["catalogue_draw_sha256"]:
            raise ValueError("Noise in zero-noise baseline")
        sim_seeds.add(int(r["simulation_seed"]))
    if expected or len(sim_seeds) != 1:
        raise ValueError(f"Missing predictor or mixed simulation seed in {folder}")
    return sim_seeds.pop(), hashlib.sha256(json.dumps(sorted(draws)).encode()).hexdigest()


def setup(out, java, smoke):
    manifest = core.read(ROOT/"package_hashes.json")
    core.verify(ROOT, manifest)
    hashes = core.read(ROOT/"frozen_source.json")["hashes"]
    package_id = core.sha(ROOT/"package_hashes.json")
    dependencies = {k: v for k, v in [
        ("numpy", __import__("numpy").__version__), ("pandas", __import__("pandas").__version__),
        ("scipy", __import__("scipy").__version__), ("xgboost", __import__("xgboost").__version__),
        ("Flask", importlib.metadata.version("Flask"))]}
    pinned = core.read(ROOT/"frozen_source.json")["package_versions"]
    if any(v != pinned[k] for k, v in dependencies.items()):
        raise RuntimeError("Python package versions differ. Run bash RUN_MAC.sh to install the pinned versions.")
    env = dict(java=java, jdk=subprocess.check_output([java,"-version"], stderr=subprocess.STDOUT,text=True).strip(),
               python_version=platform.python_version(), machine=platform.machine(), os=platform.platform(), dependencies=dependencies)
    if out.exists():
        core.require(core.sha(out/"study.json") == (out/"study.sha256").read_text().strip(), "Study settings changed")
        plan = core.read(out/"study.json")
        core.require(plan["package_id"] == package_id and plan["environment"] == env, "Package or run environment changed")
        core.verify(out, plan["runtime_hashes"])
        return plan
    with tempfile.TemporaryDirectory(dir=out.parent, prefix=".prepare-") as tmp:
        stage = Path(tmp)/"stage"
        source = stage_inputs(ROOT, stage, hashes)
        core.verify(stage, hashes)
        services = stage/"runtime/services"
        (services/"scope_lambda_service.py").rename(services/"frozen_lambda.py")
        shutil.copy2(ROOT/"driver/noise_service.py", services/"scope_lambda_service.py")
        classes = stage/"runtime/classes"
        classes.mkdir()
        src = stage/"runtime/src"
        libs = os.pathsep.join(str(p) for p in sorted((stage/"runtime/lib").glob("*.jar")))
        print("Compiling the frozen simulator with the selected JDK.", flush=True)
        core.managed([java, "-m", "jdk.compiler/com.sun.tools.javac.Main", "-classpath", libs,
                      "-sourcepath", src, "-d", classes, src/(core.MAIN.replace(".", "/")+".java")],
                     stage/"compile.log", stage)
        plan = study.protocol("full")
        plan.update(workflow="R1.10 prediction-noise experiment v1", profile="smoke" if smoke else "full",
                    purpose="workflow verification" if smoke else "closed-loop predictor-noise sensitivity",
                    iterations=[3498,3499] if smoke else list(range(3401,3411)), loads=[300 if smoke else 1800],
                    minutes=5 if smoke else 60, warmup_minutes=1 if smoke else 3, imported_calibration_jobs=[],
                    java=java, python=sys.executable, environment=env, package_id=package_id,
                    local_input_source=str(source),
                    noise_factors=list(LEVELS), noise_seed_namespace=1102026, delta_t_seconds=60,
                    runtime_hashes={str(p.relative_to(stage)):core.sha(p) for d in ("runtime","inputs","models","dataset")
                                    for p in (stage/d).rglob("*") if p.is_file()})
        for key in ("main_policies","ablation_policies","adaptation_policies","ablation_load","adaptation_load",
                    "tuning_iterations","static_shortlist_size","static_selection","parameter_selection","inference"):
            plan.pop(key, None)
        core.write(stage/"study.json", plan)
        (stage/"study.sha256").write_text(core.sha(stage/"study.json"))
        stage.rename(out)
    return plan


def publish(out, runs, comparisons, seed_checks, smoke):
    from reporting import summarize
    name = "SCOPE_R1_10_Smoke" if smoke else "SCOPE_R1_10_Results"
    with tempfile.TemporaryDirectory(dir=out) as tmp:
        report = Path(tmp)/"report"
        report.mkdir()
        (report/"runs").mkdir()
        rows = []
        for job, folder, result, sim_seed in runs:
            dest = report/"runs"/job["key"]
            dest.mkdir()
            for f in ["noise_audit.csv","result.json","health.json","config.properties","settings.json"]:
                shutil.copy2(folder/f, dest/f)
            for log in (folder/"java").glob("*_GENERIC.log"):
                shutil.copy2(log, dest/log.name)
            row = dict(iteration=job["iteration"], simulation_seed=sim_seed, noise_level=job["noise_level"],
                       vehicles=job["load"], workload_sha256=result["workload_sha256"], **result["metrics"]["ALL_APPS"],
                       changes=result["changes"], total_movement=result["total_movement"], max_step=result["max_step"])
            rows.append(row)
        write_csv(report/"per_run.csv", rows)
        write_csv(report/"pairing_checks.csv", seed_checks)
        if comparisons:
            write_csv(report/"archived_baseline_check.csv", comparisons)
        summarize(report, rows)
        for item in ["frozen_source.json","runtime_files.json","package_hashes.json","reference_at_1800.csv","README.md"]:
            shutil.copy2(ROOT/item,report/item)
        shutil.copytree(ROOT/"driver",report/"analysis_and_runner",ignore=shutil.ignore_patterns("__pycache__"))
        shutil.copy2(out/"models/model_metrics.csv",report/"calibration_metrics.csv")
        shutil.copy2(out/"study.json",report/"study.json")
        checks = dict(profile="smoke" if smoke else "full", complete_runs=len(rows), bound_verified=True,
                      six_models_every_decision=True, workload_pairing_verified=True, common_noise_verified=True,
                      all_published_baselines_match=all(r["matches_reference"] for r in comparisons) if comparisons else None)
        core.write(report/"checks.json", checks)
        zip_path=Path(tmp)/"result.zip"
        with zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for p in sorted(report.rglob("*")):
                if p.is_file(): z.write(p, str(Path(name)/p.relative_to(report)))
        with zipfile.ZipFile(zip_path) as z:
            if z.testzip(): raise ValueError("Results archive failed its integrity check")
        dest=ROOT/(name+".zip")
        zip_path.replace(dest)
        return dest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()
    for sig in [signal.SIGTERM, signal.SIGINT]: signal.signal(sig, core.signal_stop)
    work = ROOT/"work"
    work.mkdir(exist_ok=True)
    out = work/("smoke" if args.smoke else "full")
    with (work/"run.lock").open("a") as lock:
        try: fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError: raise RuntimeError("A study run is already active in this folder.") from None
        plan = setup(out, core.select_java(None), args.smoke)
        scales=model_scales(out)
        ref={int(r["iteration"]):r for r in read_csv(ROOT/"reference_at_1800.csv")}
        runs, comparisons, checks = [], [], []
        n = plan["loads"][0]
        started=time.monotonic()
        newly_run=0
        total=len(plan["iterations"])*len(LEVELS)
        for iteration in plan["iterations"]:
            identities, draws = set(), set()
            for level in LEVELS:
                job=study.spec("main","SCOPE",n,iteration,noise_level=level)
                job["key"]=f"noise{level}_i{iteration}_n{n}"
                os.environ.update(R110_ITERATION=str(iteration),R110_LEVEL=str(level))
                cached=(out/"jobs"/job["key"]/"complete.json").exists()
                folder, result=study.simulate(out,plan,job,{})
                sim_seed, draw_hash=check_noise(folder,plan,job,scales)
                identities.add((sim_seed,result["workload_sha256"]))
                if level: draws.add(draw_hash)
                if len(identities)>1 or len(draws)>1: raise ValueError(f"Pairing failed for iteration {iteration}")
                if not args.smoke and level == 0:
                    m=result["metrics"]["ALL_APPS"]
                    f_diff=m["failure_pct"]-float(ref[iteration]["failure_pct"])
                    s_diff=m["service_seconds"]-float(ref[iteration]["service_seconds"])
                    match=abs(f_diff)<1e-8 and abs(s_diff)<1e-8
                    comparisons.append(dict(iteration=iteration,failure_diff_pp=f_diff,service_diff_s=s_diff,matches_reference=match))
                    if not match: print("Baseline differs from archived results. See archived_baseline_check.csv.",flush=True)
                runs.append((job,folder,result,sim_seed))
                newly_run+=int(not cached)
                msg=f"Verified {len(runs)}/{total}"
                if cached: msg+=" (resumed)"
                elif newly_run:
                    msg+=f". Approx. {(time.monotonic()-started)/newly_run*(total-len(runs))/60:.0f} min left at this machine's current rate"
                print(msg,flush=True)
            sim_seed,workload=identities.pop()
            checks.append(dict(iteration=iteration,simulation_seed=sim_seed,workload_sha256=workload,
                               matched_levels="0,1,2",common_standard_normal_field_sha256=draws.pop()))
        dest=publish(out,runs,comparisons,checks,args.smoke)
        print(f"Verified and packaged {dest}",flush=True)
        if comparisons and not all(r["matches_reference"] for r in comparisons):
            print("Attach the archive and flag the archived-baseline mismatch before interpreting results.",flush=True)


if __name__=="__main__":
    try:
        main()
    except core.Stopped:
        print("Stopped. Run the same command to resume completed scenarios.", file=sys.stderr)
        sys.exit(130)
