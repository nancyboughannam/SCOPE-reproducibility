"""Seed-paired performance summaries for R1.10."""
import csv
import math
import numpy as np
from scipy.stats import t


def write(path, rows):
    with path.open("w", newline="") as stream:
        w = csv.DictWriter(stream, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def summarize(folder, rows):
    by_level = {level:{r["iteration"]:r for r in rows if r["noise_level"]==level} for level in (0,1,2)}
    seeds = sorted(by_level[0])
    if len(seeds)<2 or any(sorted(table)!=seeds for table in by_level.values()):
        raise ValueError("Paired summaries require complete matched seeds.")
    means = []
    contrasts = []
    for level, table in by_level.items():
        row = dict(noise_level=level, n=len(seeds))
        for metric in ["failure_pct","service_seconds","changes","total_movement","max_step"]:
            row["mean_"+metric] = np.mean([table[s][metric] for s in seeds])
        row["largest_observed_step"] = max(table[s]["max_step"] for s in seeds)
        means.append(row)
        if level == 0: continue
        for metric, unit, scale in [("failure_pct","percentage points",1),("service_seconds","ms",1000)]:
            diff = np.array([(table[s][metric]-by_level[0][s][metric])*scale for s in seeds])
            mean, se = float(diff.mean()), float(diff.std(ddof=1)/math.sqrt(len(seeds)))
            radius = t.ppf(.975, len(seeds)-1)*se
            p = 2*t.sf(abs(mean)/se, len(seeds)-1) if se else float(mean==0)
            contrasts.append(dict(noise_level=level, comparison="noise minus zero", metric=metric, unit=unit,
                                  n_pairs=len(seeds),mean_difference=mean,ci95_low=mean-radius,
                                  ci95_high=mean+radius,p_two_sided=p,p_holm=0.))
    largest = 0.
    for rank, r in enumerate(sorted(contrasts,key=lambda x:x["p_two_sided"])):
        largest=max(largest,min(1.,(len(contrasts)-rank)*r["p_two_sided"]))
        r["p_holm"]=largest
    write(folder/"level_summary.csv",means)
    write(folder/"paired_differences.csv",contrasts)
