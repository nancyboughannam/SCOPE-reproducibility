"""Locate the original v5 runtime or publication checkout and stage its verified files."""
import hashlib
import json
import os
from pathlib import Path
import shutil

STUDIES = ("v5_exp3_guard_off_3401_3410", "v5_final_3401_3410")


def source_folders(root):
    explicit = os.getenv("SCOPE_PROJECT")
    if explicit:
        projects = [Path(explicit).expanduser()]
    else:
        documents = Path.home() / "Documents"
        downloads = Path.home() / "Downloads"
        projects = [
            documents / "SCOPE-v5-testing", documents / "SCOPE-major-revision",
            root.parent, Path.cwd(), documents / "SCOPE-reproducibility",
            downloads / "SCOPE_Publication_Recovery" / "SCOPE",
            documents / "SCOPE_Publication_Recovery" / "SCOPE",
        ]
    seen = set()
    for project in projects:
        folders = [project / "ThreeBrains" / "sim_results" / name for name in STUDIES]
        for folder in [*folders, project, project / "frozen"]:
            folder = folder.resolve()
            if folder not in seen and folder.is_dir():
                seen.add(folder)
                yield folder


def stage_inputs(root, stage, expected):
    mapping = json.loads((root/"runtime_files.json").read_text())
    best = None
    for folder in source_folders(root):
        if (folder/"runtime/lib").is_dir():
            layout = {rel: rel for rel in expected}
        elif (folder/"ThreeBrains/lib").is_dir():
            layout = mapping
        else:
            continue
        failures = []
        for rel, src in layout.items():
            path = folder/src
            if not path.is_file():
                failures.append(f"missing {src}")
            elif hashlib.sha256(path.read_bytes()).hexdigest() != expected[rel]:
                failures.append(f"different version of {src}")
        if failures:
            if best is None or len(failures) < len(best[1]):
                best = folder, failures
            continue
        print(f"Using verified local SCOPE inputs from {folder}", flush=True)
        for rel, src in layout.items():
            dst = stage/rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(folder/src, dst)
        return folder
    reason = ""
    if best:
        folder, failures = best
        reason = f"\nClosest match: {folder}\n" + "\n".join(failures[:4])
    raise RuntimeError("Could not find the matching local SCOPE v5 inputs." + reason +
                       "\nSet SCOPE_PROJECT to the full path of your v5 project or original full study folder and rerun RUN_MAC.sh.")
