"""Insert candidate-specific noise between frozen inference and physical clipping."""
import csv
import hashlib
import os
from pathlib import Path

import numpy as np
import pandas as pd
from flask import g
import scope_diagnostic_service as diagnostic
import frozen_lambda

service = diagnostic.service
iteration = int(os.environ["R110_ITERATION"])
level = int(os.environ["R110_LEVEL"])
if level not in (0, 1, 2):
    raise ValueError("Unexpected noise level")
model_keys = {id(spec): key for key, spec in service.MODELS.items()}
catalogue = pd.MultiIndex.from_frame(service.CANDIDATE_CATALOGUE[service.CANDIDATE_COLUMNS])
assert len(catalogue) == 1408 and catalogue.is_unique
targets = ("failure_rate", "deadline_norm_service_time")
scales = {}
with (Path(os.environ["SCOPE_RESULTS_DIR"]) / "model_metrics.csv").open() as stream:
    for row in csv.DictReader(stream):
        if row["model_type"] == "candidate_aware_xgboost" and row["split"] == "validation":
            key = int(row["app_id"]), row["target"]
            assert key not in scales
            scales[key] = float(row["rmse"])
assert set(scales) == set(service.MODELS) and all(x > 0 for x in scales.values())
predict = service._predict_model
audit_path = Path(os.environ["SCOPE_DIAGNOSTIC_DIR"]).parent / "noise_audit.csv"
fields = ["iteration", "simulation_seed", "timestamp", "level", "app", "target", "rmse",
          "sigma", "candidates", "rms_added", "max_abs_added", "catalogue_draw_sha256"]
with audit_path.open("x") as f:
    csv.DictWriter(f, fields).writeheader()


def predict_with_noise(spec, base, candidates):
    raw = predict(spec, base, candidates)
    app, target = model_keys[id(spec)]
    req = service.request.get_json()
    timestamp = int(req["timestamp"])
    assert int(req["iteration"]) == iteration and timestamp == req["timestamp"]
    if not hasattr(g, "candidate_ids"):
        keys = candidates[service.CANDIDATE_COLUMNS]
        g.candidate_ids = catalogue.get_indexer(pd.MultiIndex.from_frame(keys))
        g.extra = np.flatnonzero(g.candidate_ids < 0)
        assert len(g.extra) <= 1 and len(set(g.candidate_ids.tolist())) == len(raw)
        if len(g.extra):
            vector = np.asarray(keys.iloc[g.extra[0]], dtype="<f8").tobytes()
            g.extra_key = int.from_bytes(hashlib.sha256(vector).digest()[:8], "little")
    sigma = level * scales[app, target]
    field_hash = ""
    if level:
        # The seed deliberately omits level. Every catalogue entry keeps its own draw,
        # including when the current configuration moves to the front of the batch.
        seed = [1102026, iteration, timestamp, app, targets.index(target)]
        field = np.random.default_rng(np.random.SeedSequence(seed)).standard_normal(len(catalogue))
        field_hash = hashlib.sha256(field.astype("<f8", copy=False).tobytes()).hexdigest()
        draw = field[g.candidate_ids]
        if len(g.extra):
            extra_rng = np.random.default_rng(np.random.SeedSequence(seed + [g.extra_key]))
            draw[g.extra[0]] = extra_rng.standard_normal()
        adjusted = raw + sigma * draw
        change = adjusted - raw
        rms = np.sqrt(np.mean(change ** 2))
        maximum = np.max(np.abs(change))
    else:
        adjusted, rms, maximum = raw, 0., 0.
    row = [iteration, req["simulation_seed"], timestamp, level, app, target,
           scales[app, target], sigma, len(raw), rms, maximum, field_hash]
    with audit_path.open("a") as f:
        csv.writer(f).writerow(row)
    return adjusted


service._predict_model = predict_with_noise
if __name__ == "__main__":
    frozen_lambda.serve()
