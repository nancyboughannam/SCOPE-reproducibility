#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
venvs=("${SCOPE_PYTHON:-}" "$HOME/Documents/SCOPE-major-revision/FLaskAPIs/.venv-revision/bin/python"
       "$HOME/Documents/SCOPE-v5-testing/FLaskAPIs/.venv-revision/bin/python"
       "${SCOPE_PROJECT:-.}/FLaskAPIs/.venv-revision/bin/python" "${VIRTUAL_ENV:-.}/bin/python"
       "$PWD/.venv/bin/python" python3.12 python3.11 python3)
verify_python() {
  "$1" -c 'import numpy, pandas, scipy, flask, xgboost; import importlib.metadata as m; from pathlib import Path; versions = dict(numpy=numpy.__version__, pandas=pandas.__version__, scipy=scipy.__version__, xgboost=xgboost.__version__, Flask=m.version("Flask")); exit(any(versions[k] != v for k,v in (s.split("==") for s in Path("requirements.txt").read_text().splitlines())))' >/dev/null 2>&1
}
runner_python=""
for candidate in "${venvs[@]}"; do
  if [[ -n "$candidate" ]] && command -v "$candidate" >/dev/null && verify_python "$candidate"; then
    runner_python="$candidate"
    echo "Using existing Python environment: $candidate"
    break
  fi
done
if [[ -z "$runner_python" ]]; then
  echo "Preparing an isolated Python environment inside the add-on."
  if [[ ! -x .venv/bin/python ]]; then
    versions=("${venvs[@]}" /opt/homebrew/bin/python3.12 /usr/local/bin/python3.12 /opt/homebrew/bin/python3.11 /usr/local/bin/python3.11)
    for candidate in "${versions[@]}"; do
      if [[ -n "$candidate" ]] && command -v "$candidate" >/dev/null && \
          "$candidate" -c 'import sys; sys.exit(sys.version_info[:2] not in [(3,11),(3,12)])'; then
        "$candidate" -m venv .venv
        break
      fi
    done
  fi
  if [[ ! -x .venv/bin/python ]]; then
    echo 'A Python 3.11 or 3.12 installation is needed to set up the pinned packages.' >&2
    exit 1
  fi
  .venv/bin/python -m pip install --disable-pip-version-check -r requirements.txt
  runner_python="$PWD/.venv/bin/python"
  "$runner_python" -c 'import xgboost'
fi
if [[ "$(uname -s)" == Darwin ]] && jdk21=$(/usr/libexec/java_home -v 21 2>/dev/null); then export JAVA_HOME="$jdk21"; fi
execute=("$runner_python" -u driver/run_noise.py)
if [[ "$(uname -s)" == Darwin ]]; then execute=(caffeinate -i "${execute[@]}"); fi
"${execute[@]}" "$@"
if [[ $# -eq 0 && "$(uname -s)" == Darwin ]]; then
  open -R "$PWD/SCOPE_R1_10_Results.zip" || echo "Results are in: $PWD/SCOPE_R1_10_Results.zip"
fi
