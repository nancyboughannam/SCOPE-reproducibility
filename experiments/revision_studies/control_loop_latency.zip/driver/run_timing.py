"""Measure the wall time for a complete local SCOPE update on the execution host."""
import csv
import difflib
import fcntl
import hashlib
import importlib.metadata
import json
import math
import os
import platform
import re
import shutil
import signal
import socket
import statistics
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile
from contextlib import contextmanager
from pathlib import Path

import run_deadline_pilot as core
from local_inputs import stage_inputs

ROOT = Path(__file__).resolve().parents[1]
SEEDS = (3401, 3402, 3403)
TIMES = list(range(70, 3600, 60))
WARMUP = 180
SOURCE = Path("runtime/src/edu/boun/edgecloudsim/applications/sample_app5/VehicularEdgeOrchestrator.java")


def csv_read(path):
    with path.open(newline="") as f:
        return list(csv.DictReader(f))


def csv_write(path, rows):
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def host_info(java):
    def output(*cmd):
        return subprocess.check_output(cmd, text=True, stderr=subprocess.STDOUT).strip()
    values = dict(os=platform.platform(), architecture=platform.machine(),
                  python=platform.python_version(), java=output(java, "-version"))
    import xgboost
    values["packages"] = {k:importlib.metadata.version(k) for k in ["numpy","pandas","scipy","Flask"]}
    values["packages"]["xgboost"] = xgboost.__version__
    if sys.platform == "darwin":
        values.update(chip=output("/usr/sbin/sysctl","-n","machdep.cpu.brand_string"),
                      physical_cores=int(output("/usr/sbin/sysctl","-n","hw.physicalcpu")),
                      memory_bytes=int(output("/usr/sbin/sysctl","-n","hw.memsize")),
                      macOS=output("/usr/bin/sw_vers","-productVersion"))
    return values


def instrument(stage):
    p = stage/SOURCE
    original = p.read_text()
    snapshot = "        final OptimizerStateSnapshot inputState = captureOptimizerState(timestamp);"
    apply = "                applyCandidateConfiguration(validated);"
    core.require(original.count(snapshot)==original.count(apply)==1, "Unexpected Java timer boundaries")
    revised = original.replace(snapshot, "        final long scopeStartNanos = System.nanoTime();\n"+snapshot)
    revised = revised.replace(apply, apply +
        '\n                final long scopeUpdateNanos = System.nanoTime() - scopeStartNanos;' +
        '\n                System.out.println("R115_TIMING " + (long) timestamp + " " + scopeUpdateNanos);')
    p.write_text(revised)
    (stage/"timing.patch").write_text("".join(difflib.unified_diff(original.splitlines(True),
        revised.splitlines(True), fromfile="original/"+str(SOURCE), tofile="timed/"+str(SOURCE))))


def prepare(out, java, hardware):
    core.verify(ROOT, core.read(ROOT/"package_hashes.json"))
    package_id=core.sha(ROOT/"package_hashes.json")
    expected = core.read(ROOT/"frozen_source.json")["hashes"]
    if out.exists():
        plan = core.read(out/"protocol.json")
        core.require(plan["package_id"]==package_id and plan["hardware"]==hardware,
                     "The experiment package or execution host changed since preparation.")
        core.verify(out,plan["runtime_hashes"])
        return
    with tempfile.TemporaryDirectory(dir=ROOT) as temp:
        stage=Path(temp)/"stage"
        source=stage_inputs(ROOT,stage,expected)
        core.verify(stage,expected)
        instrument(stage)
        src=stage/"runtime/src"
        classes=stage/"runtime/classes"
        classes.mkdir()
        jars=os.pathsep.join(str(p) for p in sorted((stage/"runtime/lib").glob("*.jar")))
        print("Compiling the timed simulator in the add-on folder.",flush=True)
        core.managed([java,"-m","jdk.compiler/com.sun.tools.javac.Main","-classpath",jars,
                      "-sourcepath",src,"-d",classes,src/(core.MAIN.replace(".","/")+".java")],
                     stage/"compile.log",stage)
        hashes={str(p.relative_to(stage)):core.sha(p) for base in ("inputs","runtime","models","dataset")
                for p in (stage/base).rglob("*") if p.is_file()}
        core.write(stage/"protocol.json", dict(package_id=package_id, local_source=str(source), hardware=hardware,
            iterations=list(SEEDS), load=1800, minutes=60, warmup_seconds=WARMUP, interval_seconds=60,
            lambda_value=.01, r_max=.15, catalogue=1408, url="http://127.0.0.1:5002/optimize",
            primary_population="All updates at or after 180 simulated seconds, including unchanged configurations",
            timer="Java System.nanoTime before captureOptimizerState through return from applyCandidateConfiguration",
            quantile="Median and linearly interpolated 95th percentile at index (n-1)*0.95",
            service="Frozen ml_optimizer_service, normal decision CSV logging enabled, extended diagnostics off",
            runtime_hashes=hashes))
        stage.rename(out)


@contextmanager
def optimizer(out, folder):
    with socket.socket() as probe:
        probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try: probe.bind(("127.0.0.1",5002))
        except OSError as exc: raise RuntimeError("Port 5002 is occupied. Stop the existing optimizer, then rerun.") from exc
    env=core.env()
    env.update(SCOPE_RESULTS_DIR=str(out/"models"), SCOPE_CANDIDATE_DATASET=str(out/"dataset/candidate_dataset_train.csv"),
               SCOPE_ABLATION_RESULTS_DIR=str(folder/"ordinary"), SCOPE_HARD_STABILITY="1", SCOPE_PORT="5002",
               SCOPE_LAMBDA=".01", SCOPE_R_MAX=".15", SCOPE_W_FAILURE=".5", SCOPE_W_SERVICE=".5")
    command=[sys.executable, "-u", "-c",
             "import ml_optimizer_service as s; s.app.run(host='127.0.0.1', port=s.PORT, threaded=False, debug=False, use_reloader=False)"]
    with (folder/"service.log").open("w") as log:
        process=subprocess.Popen(command,cwd=out/"runtime/services",env=env,stdout=log,stderr=log,start_new_session=True)
        try:
            deadline=time.monotonic()+90
            while True:
                core.check_stop(out)
                core.require(process.poll() is None, f"Optimizer exited. See {folder/'service.log'}")
                try:
                    with urllib.request.urlopen("http://127.0.0.1:5002/health",timeout=1) as response:
                        h=json.load(response)
                except (OSError,ValueError):
                    core.require(time.monotonic()<deadline,"Optimizer startup timed out")
                    time.sleep(.2)
                    continue
                core.require(h["status"]=="ready" and h["automatic_decision_log_root"]==str(folder/"ordinary")
                    and h["candidate_count"]==1408 and h["models_loaded"]==6 and h["routing_schema"]==core.SCHEMA
                    and h["lambda"]==.01 and h["r_max"]==.15 and h["hard_stability_enabled"]
                    and h["w_failure"]==h["w_service"]==.5,"Unexpected local optimizer or model settings")
                core.write(folder/"health.json",h)
                break
            yield process
        finally:
            core.terminate(process)


def verify_run(folder, iteration, expected):
    log=(folder/"java.log").read_text()
    ident=re.findall(r"WORKLOAD_AUDIT [^\n]*sha256=([a-f0-9]{64})",log)
    core.require(ident==[expected["workload_sha256"]] and "ROUTING_SCHEMA="+core.SCHEMA in log,"Unexpected workload or routing schema")
    measured=[(int(t),int(ns)) for t,ns in re.findall(r"R115_TIMING (\d+) (\d+)",log)]
    files=list((folder/"ordinary").rglob("*.csv"))
    core.require(len(files)==1,"Missing or ambiguous optimizer decision log")
    service=csv_read(files[0])
    core.require([t for t,_ in measured]==TIMES and [float(s["timestamp"]) for s in service]==TIMES,
                 "Missing or repeated clock records or optimizer decisions")
    rows=[]
    same_actions=True
    for (t,ns),s,a in zip(measured,service,expected["actions"],strict=True):
        core.require(int(s["iteration"])==iteration and int(s["num_devices"])==1800 and s["policy"]=="SCOPE"
                     and float(a["timestamp"])==t and int(s["candidate_count"]) in (1408,1409)
                     and s["hard_stability_enabled"]=="True" and s["stability_violation"]=="False","Invalid decision identity/settings")
        server_ms=float(s["optimizer_time_ms"])
        core.require(0<server_ms<=ns/1e6 and math.isfinite(server_ms),"Invalid client or server timing")
        same_actions &= all(abs(float(s[k.replace("candidate_","selected_")])-a[k])<=1e-9 for k in core.COLS)
        rows.append(dict(iteration=iteration, simulation_seed=int(s["simulation_seed"]), simulated_seconds=t,
                         post_warmup=int(t>=WARMUP), candidates=int(s["candidate_count"]),
                         reconfigured=s["reconfigured"], local_control_loop_ns=ns, local_control_loop_ms=ns/1e6,
                         optimizer_ms=server_ms))
    m=core.generic(folder/"java/SIMRESULT_ITS_SCENARIO_SCOPE_1800DEVICES_ALL_APPS_GENERIC.log")
    same_tasks=all(math.isclose(m[k],v,rel_tol=0,abs_tol=1e-10) for k,v in expected["outcomes"].items())
    core.require(len({r["simulation_seed"] for r in rows})==1, "Seed changed within a run")
    csv_write(folder/"updates.csv",rows)
    return dict(iteration=iteration, decisions=len(rows), outcome_reference_matches=same_tasks,
                all_action_reference_matches=same_actions, workload_sha256=ident[0], metrics=m)


def run_seed(out,java,iteration,expected):
    key=f"i{iteration}"
    cached=core.complete(out,key)
    if cached:
        print(f"Verified checkpoint for {iteration}.",flush=True)
        return out/cached["attempt"],cached["result"]
    core.check_stop(out)
    folder=core.attempt(out,key)
    (folder/"java").mkdir()
    config=(out/"inputs/base.properties").read_text()
    for name,value in dict(simulation_time=60,warm_up_period=3,min_number_of_mobile_devices=1800,
                           max_number_of_mobile_devices=1800,mobile_device_counter_size=1,
                           orchestrator_policies="SCOPE",file_log_enabled="true",deep_file_log_enabled="false").items():
        config,count=re.subn(r"(?m)^"+name+r"=.*$",name+"="+str(value),config)
        core.require(count==1,"Unexpected property "+name)
    (folder/"config.properties").write_text(config)
    (folder/"weka").symlink_to(out/"inputs/weka", target_is_directory=True)
    command=[java,"-Xmx2g","-Dscope.optimizer.failFast=true","-Dscope.deadlineTierGuard=true",
             "-Dscope.auditWorkload=true","-Dscope.logPerformanceWindows=false",
             "-Dscope.trainingData.path="+str(folder/"candidate_windows.csv"),"-cp",core.cp(out),core.MAIN,
             str(folder/"config.properties"),str(out/"inputs/edge_devices.xml"),str(out/"inputs/applications.xml"),
             str(folder/"java"),str(iteration)]
    started=time.monotonic()
    with optimizer(out,folder) as peer:
        core.managed(command,folder/"java.log",out,cwd=out,environ=core.env(),peer=peer)
    result=verify_run(folder,iteration,expected)
    result["run_elapsed_seconds"]=time.monotonic()-started
    core.receipt(out,key,folder,result)
    return folder,result


def quantile95(values):
    values=sorted(values)
    position=.95*(len(values)-1)
    i=math.floor(position)
    return values[i]+(position-i)*(values[math.ceil(position)]-values[i])


def summarize(group, rows):
    a=[float(r["local_control_loop_ms"]) for r in rows]
    b=[float(r["optimizer_ms"]) for r in rows]
    return dict(sample=group, n=len(rows), loop_median_ms=statistics.median(a),loop_p95_ms=quantile95(a),
                loop_max_ms=max(a),optimizer_median_ms=statistics.median(b),optimizer_p95_ms=quantile95(b))


def publish(out,runs):
    with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
        tmp=Path(tmp)
        rows=[r for folder,_ in runs for r in csv_read(folder/"updates.csv")]
        primary=[r for r in rows if r["post_warmup"]=="1"]
        sums=[summarize("pooled_post_warmup",primary),summarize("pooled_all_updates",rows)]
        for seed in SEEDS:
            sums.append(summarize(f"{seed}_post_warmup",[r for r in primary if int(r["iteration"])==seed]))
        csv_write(tmp/"updates.csv",rows)
        csv_write(tmp/"summary.csv",sums)
        core.write(tmp/"checks.json",[result for _,result in runs])
        name="SCOPE_R1_15_Results"
        archive=tmp/(name+".zip")
        with zipfile.ZipFile(archive,"w",zipfile.ZIP_DEFLATED) as z:
            for fn in ["updates.csv","summary.csv","checks.json"]: z.write(tmp/fn,name+"/"+fn)
            for fn in ["timing.patch","protocol.json"]: z.write(out/fn,name+"/"+fn)
            for fn in ["README.md","package_hashes.json","driver/run_timing.py","reference.json"]: z.write(ROOT/fn,name+"/"+fn)
            for folder,result in runs:
                prefix=name+"/runs/i"+str(result["iteration"])+"/"
                for fn in ["result.json","config.properties","health.json","java.log"]:
                    z.write(folder/fn,prefix+fn)
                service_log,=(folder/"ordinary").rglob("*.csv")
                z.write(service_log,prefix+"optimizer_decisions.csv")
                log="SIMRESULT_ITS_SCENARIO_SCOPE_1800DEVICES_ALL_APPS_GENERIC.log"
                z.write(folder/"java"/log,prefix+log)
        with zipfile.ZipFile(archive) as z:
            core.require(z.testzip() is None,"Results ZIP integrity check failed")
        target=ROOT/archive.name
        archive.replace(target)
    print(f"Primary summary, {len(primary)} updates: median {sums[0]['loop_median_ms']:.3f} ms, "
          f"95th percentile {sums[0]['loop_p95_ms']:.3f} ms.",flush=True)
    if any(not r["all_action_reference_matches"] or not r["outcome_reference_matches"] for _,r in runs):
        print("The baseline comparison flagged a difference. Attach the ZIP for review before using the times.",flush=True)
    print(f"Results verified and saved to {target}",flush=True)


def main():
    if len(sys.argv)!=1:
        raise SystemExit("Usage: bash RUN_MAC.sh")
    for sig in (signal.SIGINT,signal.SIGTERM): signal.signal(sig,core.signal_stop)
    with (ROOT/"run.lock").open("a") as lock:
        try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise RuntimeError("Another timing run is active in this folder.") from None
        java=core.select_java(None)
        out=ROOT/"work"
        prepare(out,java,host_info(java))
        ref=core.read(ROOT/"reference.json")
        runs=[]
        for index,seed in enumerate(SEEDS,1):
            print(f"Run {index}/{len(SEEDS)} at 1,800 vehicles (iteration {seed})",flush=True)
            runs.append(run_seed(out,java,seed,ref[str(seed)]))
        publish(out,runs)


if __name__=="__main__":
    try: main()
    except core.Stopped: raise SystemExit("Interrupted. Run the same command to resume completed seeds.")
