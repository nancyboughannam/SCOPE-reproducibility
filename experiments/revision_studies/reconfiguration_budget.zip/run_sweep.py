"""Run the revised SCOPE planner across four hard update budgets."""
import argparse
import csv
import fcntl
import importlib.metadata
import json
import math
import os
import platform
import signal
import statistics
import subprocess
import sys
import tempfile
from pathlib import Path

import run_deadline_pilot as core
import run_lambda_check as runner
from local_inputs import stage_inputs

HERE = Path(__file__).resolve().parent
BUDGETS = [0.10, 0.15, 0.20, 0.30]
ITERATIONS = [3301, 3302, 3303]
METRICS = ['failure_pct', 'service_seconds', 'changes', 'total_movement', 'max_step']
DESIGN = {
    'budgets': BUDGETS, 'iterations': ITERATIONS, 'lambda': 0.01, 'minutes': 60,
    'warmup_minutes': 3, 'vehicles': 1800, 'planning_interval_seconds': 60,
    'design': 'Post-main-study sensitivity analysis. Original four budget values and original fixed-load design with three paired revised development iterations. Full one-hour closed-loop rerun of each cell.',
    'scope': 'Descriptive study in one fixed workload. Report failure, completed-task service time, and movement together. No equivalence margin or economic cost assumed.',
    'interpretation': 'Show all results, report outcome-specific minima and trade-offs. Call two settings identical on these runs only when all three selected-configuration trajectories and task outcomes are identical. No universal optimum or retroactive main-study tuning claim.',
}

def csvfile(path, rows):
    with path.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

def setup(work):
    import xgboost
    versions = {k: importlib.metadata.version(k) for k in ['numpy', 'pandas', 'scipy', 'Flask']}
    versions['xgboost'] = xgboost.__version__
    source = core.read(HERE/'frozen_source.json')
    core.require(all(source['package_versions'][k] == v for k,v in versions.items()), 'Python dependency versions differ from the revised experiment')
    java = core.select_java(None)
    metadata = dict(design=DESIGN, source_hashes=source['hashes'], python=platform.python_version(),
                    dependencies=versions, java=java, java_version=subprocess.check_output([java,'-version'],stderr=subprocess.STDOUT,text=True),
                    scripts={p.name:core.sha(p) for p in HERE.glob('*.py')})
    if work.exists():
        existing=core.read(work/'protocol.json')
        core.require(all(existing[k]==v for k,v in metadata.items()), 'Run environment or protocol changed; use a fresh output folder')
        core.verify(work,source['hashes'])
        core.verify(work/'runtime/classes',existing['classes'])
        return java
    with tempfile.TemporaryDirectory(dir=work.parent) as tmp:
        stage=Path(tmp)/'stage'
        project=stage_inputs(HERE,stage,source['hashes'])
        classes=stage/'runtime/classes'
        classes.mkdir()
        src=stage/'runtime/src'
        libs=os.pathsep.join(str(p) for p in sorted((stage/'runtime/lib').glob('*.jar')))
        core.managed([java,'-m','jdk.compiler/com.sun.tools.javac.Main','-classpath',libs,'-sourcepath',src,'-d',classes,src/(core.MAIN.replace('.','/')+'.java')],stage/'compile.log',stage)
        core.write(stage/'protocol.json',dict(metadata, source=str(project),classes=core.hashes(classes)))
        stage.rename(work)
    return java

def run(work, report):
    java=setup(work)
    report.mkdir(exist_ok=True,parents=True)
    raw=report/'runs'
    raw.mkdir(exist_ok=True)
    references={int(row['iteration']):row for row in csv.DictReader((HERE/'archived_reference.csv').open())}
    allrows=[]
    paired=[]
    checks=[]
    for i in ITERATIONS:
        trajectories={}
        outcomes={}
        fingerprints=set()
        # Reproduce the recorded setting before changing the budget.
        for budget in [0.15,0.10,0.20,0.30]:
            key=f'r{round(budget*100):02d}_i{i}'
            job=dict(key=key,case='steady',variant='adaptive',load=DESIGN['vehicles'],iteration=i,lambda_value=DESIGN['lambda'],r_max=budget)
            plan=dict(minutes=DESIGN['minutes'],warmup_minutes=DESIGN['warmup_minutes'],java=java,r_max=budget)
            receipt=runner.simulate(work,plan,job)
            res=receipt['result']
            core.require(res['spec']==job,'Stored job parameters differ')
            folder=work/receipt['attempt']
            fingerprints.add(res['workload_sha256'])
            core.require(len(fingerprints)==1,f'Workloads differ for iteration {i}')
            records=runner.decision_records(folder)
            runner.validate_decisions(records,plan,job)
            trajectory=[[r['request']['timestamp']]+[r['selected']['configuration'][k] for k in core.COLS] for r in records]
            trajectories[budget]=trajectory
            metrics=res['metrics']['ALL_APPS']
            outcomes[budget]=dict(metrics,**{k:res[k] for k in ['total_movement','max_step','changes']})
            audit={'iteration':i,'r_max':budget,'workload_sha256':res['workload_sha256'],'decision_count':len(records)}
            if budget==.15:
                ref=references[i]
                for k in ['completed','failed','pending',*METRICS]:
                    core.require(math.isclose(outcomes[budget][k],float(ref[k]),rel_tol=0.,abs_tol=1e-9),f'Archived control mismatch at {i} for {k}: {outcomes[budget][k]} versus {ref[k]}')
                audit['archived_reference']='matched'
            else:
                audit['archived_reference']=''
            checks.append(audit)
            allrows.append(dict(iteration=i,r_max=budget,**outcomes[budget]))
            dest=raw/key
            dest.mkdir(exist_ok=True)
            for filename in ['health.json','result.json','config.properties','settings.json','java.log']:
                (dest/filename).write_bytes((folder/filename).read_bytes())
            for logfile in (folder/'java').glob('*_GENERIC.log'):
                (dest/logfile.name).write_bytes(logfile.read_bytes())
            csvfile(dest/'decisions.csv',[dict(timestamp=r[0],**dict(zip(core.COLS,r[1:])),movement=record['selected']['reconfiguration_cost']) for r,record in zip(trajectory,records)])
        for b in BUDGETS:
            paired.append(dict(iteration=i,r_max=b,baseline_r_max=.15,
                identical_decisions=trajectories[b]==trajectories[.15],
                identical_task_outcomes=all(outcomes[b][k]==outcomes[.15][k] for k in ['completed','failed','pending','service_seconds']),
                different_decisions=sum(left!=right for left,right in zip(trajectories[b],trajectories[.15])),
                **{k+'_diff':outcomes[b][k]-outcomes[.15][k] for k in METRICS}))
    csvfile(report/'per_run.csv',allrows)
    csvfile(report/'paired_vs_015.csv',paired)
    csvfile(report/'checks.csv',checks)
    summary=[]
    for b in BUDGETS:
        rows=[r for r in allrows if r['r_max']==b]
        summary.append(dict(r_max=b,iterations=len(rows),**{k+'_mean':statistics.mean(r[k] for r in rows) for k in METRICS},
          **{k+'_sd':statistics.stdev(r[k] for r in rows) for k in METRICS},largest_individual_step=max(r['max_step'] for r in rows)))
    csvfile(report/'summary.csv',summary)
    (report/'protocol.json').write_bytes((work/'protocol.json').read_bytes())
    print(f'All {len(allrows)} scenarios completed and validated. Results: {report}',flush=True)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=Path.cwd()/'rmax_rerun')
    args=parser.parse_args()
    out=args.output.resolve()
    out.mkdir(parents=True,exist_ok=True)
    for sig in [signal.SIGTERM,signal.SIGINT]:
        signal.signal(sig,core.signal_stop)
    with (out/'run.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        run(out/'work',out/'results')

if __name__=='__main__':
    main()
